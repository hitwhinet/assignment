<?php
return array(
	//格式：用户ID => array(用户名, 密码)
	1 => array('username'=> 'xiaoming', 'password'=> '123456'),
	//2 => array() //……其他用户的代码这里省略
);