<?php
return array(
	//用户信息表单选项
	'userinfo' => array(
		'blood' => array('未知','A','B','O','AB','其它'),
		'hobby'=> array('跑步','游泳','唱歌','登山','旅游','看电影','读书')
		
	)
);