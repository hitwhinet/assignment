<?php
//载入项目初始化脚本
require './init.php';

//判断用户是否登录，如果登录，获取用户ID
$user_id = checkLogin();  //如果没有登录，自动跳转到登录

/*
此处连接数据库 读取学生信息
 */

//载入修改用户信息的页面文件
require './view/showinfo-Student.html';