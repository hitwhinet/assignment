<?php
//载入项目初始化脚本
require './init.php';

//判断用户是否登录，如果登录，获取用户ID
$user_id = checkLogin();  //如果没有登录，自动跳转到登录

if($_POST){
	$teachername = array();
	$teachername['name'] = $_POST['name'];
	$freetime = array(
	 array("2018/03/30", 1, "战略忽悠学院", "研究院2号楼666", 13800138000),
	 array("2018/04/01", 2, "澄空学园", "中3", 17863136275),
	 array("2018/05/01", 3, "山大（威海）学院", "教3-10086", 17051102480)
	);
}

if($_GET){
	$date = isset($_GET['date'])?$_GET['date']:"";
	$clsid = isset($_GET['clsid'])?$_GET['clsid']:0;
	$tname = isset($_GET['tname'])?$_GET['tname']:"";

	//执行数据库操作
	$orderresult = $date.$clsid.$tname;
}

//载入查询教师闲时、预约时间的页面文件 
require './view/ordertime.html';