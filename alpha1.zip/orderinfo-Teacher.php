<?php
//载入项目初始化脚本
require './init.php';

//判断用户是否登录，如果登录，获取用户ID
$user_id = checkLogin();  //如果没有登录，自动跳转到登录


$orderinfo = array(
	 array("2018/03/30", 1, 150430233, "战略忽悠学院", "令狐冲"),
	 array("2018/04/01", 2, 140140140, "海底捞针学院", "左冷禅"),
	 array("2018/05/01", 3, 170770777, "上天揽月学院", "李莫愁")
);


//载入查询学生预约情况的页面文件
require './view/orderinfo-Teacher.html';