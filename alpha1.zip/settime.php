<?php
//载入项目初始化脚本
require './init.php';

//判断用户是否登录，如果登录，获取用户ID
$user_id = checkLogin();  //如果没有登录，自动跳转到登录

$clstime = array(1,2,3,4,5,6);

//读取教师空闲时间
$freetime = array(
	 array("2018/03/30", 1, "战略忽悠学院", "研究院2号楼666", 13800138000),
	 array("2018/04/01", 2, "澄空学园", "中3", 17863136275),
	 array("2018/05/01", 3, "山大（威海）学院", "教3-10086", 17051102480)
);

//响应POST操作
if($_POST){
	$success = true;
}

//载入显示用户信息的页面文件
require './view/settime.html';