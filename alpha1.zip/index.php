<?php
header('Location: selection.php');
exit;